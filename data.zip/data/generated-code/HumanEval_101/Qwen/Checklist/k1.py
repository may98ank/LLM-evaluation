def words_string(s):
    # Split the string by commas or spaces and return the resulting list of words
    return s.split(', ') + s.split(' ')