def words_string(s):
    # Split the string by commas or spaces and return the result as a list of words
    return s.split(', ') or s.split(' ')